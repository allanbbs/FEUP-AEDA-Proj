var searchData=
[
  ['addbrand_0',['addBrand',['../class_workshop.html#a71ceec25d6f9934cddba1d1cd72cd30b',1,'Workshop']]],
  ['addcamiao_1',['addCamiao',['../class_empresa.html#adecbe6faf9d700e39b6ad5323b2db883',1,'Empresa::addCamiao()'],['../class_servicos.html#acb65e3d707266711fb371f7e4844e6f9',1,'Servicos::addCamiao()']]],
  ['addcamiaoid_5fservico_2',['addCamiaoId_Servico',['../class_empresa.html#a4e727d2a339654602a9331880f5351c9',1,'Empresa']]],
  ['addclientes_3',['addClientes',['../class_empresa.html#ab5a333dc8c915a4a5486a76fb7478522',1,'Empresa']]],
  ['addedtoservice_4',['addedToService',['../class_camiao.html#adc6e47bbab46967157e5f9f36e91d6d0',1,'Camiao']]],
  ['addmotorista_5',['addMotorista',['../class_empresa.html#a7bb41c231a4cb3bd17fd7c45ab8e859c',1,'Empresa::addMotorista()'],['../class_workers.html#a8eba9f46cc6164f34272b64e8018cf0e',1,'Workers::addMotorista()']]],
  ['addservice_6',['addService',['../class_clientes.html#ae5f6552d13506086482c454b99092da3',1,'Clientes']]],
  ['addservico_7',['addServico',['../class_empresa.html#ad6372389d7a306c8cec6e9081e735c63',1,'Empresa']]],
  ['addworkshop_8',['addWorkshop',['../class_empresa.html#ab03713409b17a0a7cf03d4a2329e9a72',1,'Empresa']]],
  ['allocatecamiao_9',['allocateCamiao',['../class_empresa.html#aa2957222e9b2fe295136f93f8444d64f',1,'Empresa']]],
  ['allocatemotorista_10',['allocateMotorista',['../class_empresa.html#a05ed3f13c73ab623ade0622891e0cbe9',1,'Empresa::allocateMotorista()'],['../class_workers.html#a73d66724649c7e10df6d3baac00df5c6',1,'Workers::allocateMotorista()']]],
  ['animals_11',['Animals',['../class_animals.html',1,'Animals'],['../class_animals.html#aee5921e972a751a977cd91bde546a4ed',1,'Animals::Animals()']]]
];
