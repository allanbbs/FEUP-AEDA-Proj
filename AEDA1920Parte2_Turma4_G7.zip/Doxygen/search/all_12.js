var searchData=
[
  ['validclientnif_184',['validClientNif',['../utils_8h.html#ad82614aca3f56dcf76ff82abb86cef03',1,'validClientNif(Empresa &amp;e):&#160;utils.cpp'],['../utils_8cpp.html#ad82614aca3f56dcf76ff82abb86cef03',1,'validClientNif(Empresa &amp;e):&#160;utils.cpp']]],
  ['validserviceid_185',['validServiceId',['../utils_8h.html#aee6fc6707ff3eaa39890a34299344dd8',1,'validServiceId(Empresa &amp;e):&#160;utils.cpp'],['../utils_8cpp.html#aee6fc6707ff3eaa39890a34299344dd8',1,'validServiceId(Empresa &amp;e):&#160;utils.cpp']]]
];
