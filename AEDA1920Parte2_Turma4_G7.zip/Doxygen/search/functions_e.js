var searchData=
[
  ['reacceptclient_362',['reAcceptClient',['../class_empresa.html#a0de4eb82c44af2365df9ff7ba7f77e04',1,'Empresa']]],
  ['readmotorista_363',['readMotorista',['../class_empresa.html#a1c46789c0252f23906a02f0dcb3521b1',1,'Empresa::readMotorista()'],['../class_workers.html#a70699d15e66f97d16c63b98f251791da',1,'Workers::readMotorista()']]],
  ['removeclient_364',['removeClient',['../class_empresa.html#a0a180803d6252ce2752fea0e7f5a1f5c',1,'Empresa']]],
  ['removemotorista_365',['removeMotorista',['../class_empresa.html#ab7588fbfa5880ba3b87b682511f2d4fd',1,'Empresa::removeMotorista()'],['../class_workers.html#a030ab46e0003f5df8a052df6ce338baf',1,'Workers::removeMotorista()']]],
  ['removetruck_366',['removeTruck',['../class_camiao.html#a7a2a1d3ec747b697211e320fee18ed90',1,'Camiao::removeTruck()'],['../class_empresa.html#aff124092a9d1ba883a5462dea5ca1d74',1,'Empresa::removeTruck()']]],
  ['removeworkshop_367',['removeWorkshop',['../class_empresa.html#adbcd8e86250b388b0c9853694e9d5bfd',1,'Empresa']]],
  ['requestgenericservice_368',['requestGenericService',['../class_camiao.html#ac8331f1cde5cfb04a072862ab852121b',1,'Camiao']]],
  ['requestservice_369',['requestService',['../class_empresa.html#a34136c09c1e393449095e9ea0979376a',1,'Empresa']]],
  ['requestspecificservice_370',['requestSpecificService',['../class_camiao.html#a0260cf6703d3569e2d420d72d17846f7',1,'Camiao']]],
  ['resethours_371',['resetHours',['../class_empresa.html#a3515eccfbbc49f59bc00feaadde4836e',1,'Empresa::resetHours()'],['../class_workers.html#a102ae62afb65309ab87c1554714c6d14',1,'Workers::resetHours()']]],
  ['rewrite_5ffile_372',['rewrite_file',['../class_workers.html#a2a6be4529f5c7e06fc4fa2d9ce432ab1',1,'Workers']]],
  ['rewriteclients_373',['rewriteClients',['../class_empresa.html#a095eaafe3bd2c08914f8e0e7ab075f2e',1,'Empresa']]],
  ['rewritetruck_374',['rewriteTruck',['../class_empresa.html#a632509f2cb440b2ae5f27178c66cf2d6',1,'Empresa']]],
  ['rewriteworkshops_375',['rewriteWorkshops',['../class_empresa.html#a7f140e37bec27cbcab2eadc96bfa2e69',1,'Empresa']]]
];
