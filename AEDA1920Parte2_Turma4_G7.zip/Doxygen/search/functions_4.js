var searchData=
[
  ['empresa_291',['Empresa',['../class_empresa.html#aff124b958356c479ab50ddf4cf302193',1,'Empresa']]],
  ['error_292',['Error',['../class_error.html#a0d333bb759a0b4d6bbea67992fc28771',1,'Error']]]
];
