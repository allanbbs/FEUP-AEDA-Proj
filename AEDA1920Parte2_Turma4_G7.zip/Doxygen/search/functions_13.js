var searchData=
[
  ['wait_394',['wait',['../utils_8h.html#aa3b21853f890838c88d047d6c2786917',1,'wait():&#160;utils.cpp'],['../utils_8cpp.html#aa3b21853f890838c88d047d6c2786917',1,'wait():&#160;utils.cpp']]],
  ['workers_395',['Workers',['../class_workers.html#a63358dd7aac80d5dc2fc59bbf25a6c6f',1,'Workers']]],
  ['workshop_396',['Workshop',['../class_workshop.html#a1f488db0dc18130084ee7b083c26b87a',1,'Workshop::Workshop(string name)'],['../class_workshop.html#acd56befa48b8f96ffe5ce23a43f21e51',1,'Workshop::Workshop(string name, vector&lt; string &gt; &amp;aux, int nani)']]]
];
