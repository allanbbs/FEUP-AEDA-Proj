var searchData=
[
  ['table_411',['table',['../class_tax_table.html#ad399944d0c2ad575058715f7096eb488',1,'TaxTable']]],
  ['totalprofit_412',['totalProfit',['../class_camiao.html#a059cbe4520a4fd90c4c92389eac1bb7f',1,'Camiao']]]
];
