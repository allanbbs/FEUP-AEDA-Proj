var searchData=
[
  ['tablesize_388',['tableSize',['../class_tax_table.html#a205d1e488c0f4e42b971ccd9ebdf9caa',1,'TaxTable']]],
  ['taxtable_389',['TaxTable',['../class_tax_table.html#a33ae418890b3213604d3f227edd2fc95',1,'TaxTable']]]
];
