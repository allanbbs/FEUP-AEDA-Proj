var searchData=
[
  ['operator_3c_351',['operator&lt;',['../class_motorista.html#a1d738b913d35e4d451cc1007aa66cbdb',1,'Motorista::operator&lt;()'],['../class_workshop.html#a260958c790b4149c40f4d443fec8979e',1,'Workshop::operator&lt;()']]],
  ['operator_3c_3c_352',['operator&lt;&lt;',['../_clientes_8cpp.html#a78de7cb76f32122213afd7214f214616',1,'operator&lt;&lt;(ostream &amp;out, const Clientes &amp;client):&#160;Clientes.cpp'],['../_motorista_8cpp.html#a50558bd167c60ece0454bd5938990451',1,'operator&lt;&lt;(ostream &amp;out, const Motorista &amp;w):&#160;Motorista.cpp'],['../_servicos_8cpp.html#a84cb7a352719a8f5eec098b422d00a4e',1,'operator&lt;&lt;(ostream &amp;os, Servicos servico):&#160;Servicos.cpp'],['../_workshop_8cpp.html#a683df923856486237ad9a32155d0505d',1,'operator&lt;&lt;(ostream &amp;out, Workshop w):&#160;Workshop.cpp']]],
  ['operator_3d_3d_353',['operator==',['../class_motorista.html#a78015854b79350254c7583ab57dac505',1,'Motorista::operator==()'],['../class_workshop.html#a0f144f8b8797fa3a11e3c714a95865c3',1,'Workshop::operator==()']]]
];
