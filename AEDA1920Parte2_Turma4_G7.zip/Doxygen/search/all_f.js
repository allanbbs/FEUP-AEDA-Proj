var searchData=
[
  ['searchcli_160',['SearchCli',['../class_empresa.html#a58a26bec368815a4608660af549855c1',1,'Empresa']]],
  ['searchinactiveclient_5fhash_161',['SearchInactiveClient_hash',['../class_empresa.html#aceff12302ebd842f2e66dfe9e03b7b94',1,'Empresa']]],
  ['searchser_162',['SearchSer',['../class_empresa.html#ac5fbe498ebe030b3bf4a9e97f723733f',1,'Empresa']]],
  ['servicos_163',['Servicos',['../class_servicos.html',1,'Servicos'],['../class_servicos.html#a2dd03511fdd7000baa348399db25953f',1,'Servicos::Servicos()'],['../class_servicos.html#a3d13785920b978659634b079bea2bed3',1,'Servicos::Servicos(const Local &amp;Departure, const Local &amp;Arrival, const unsigned int &amp;Id, const string &amp;Tipo, const int &amp;Carga, const string &amp;Condition=&quot;None&quot;)']]],
  ['servicos_2ecpp_164',['Servicos.cpp',['../_servicos_8cpp.html',1,'']]],
  ['servicos_2eh_165',['Servicos.h',['../_servicos_8h.html',1,'']]],
  ['setdate_166',['setDate',['../class_clientes.html#acf060bfcee75f7a891762e1200edf502',1,'Clientes::setDate()'],['../class_date.html#a5b25692df4700680653cec7185d26124',1,'Date::setDate()']]],
  ['sethours_167',['setHours',['../class_motorista.html#a8400f01e9fae2708c83ae8ee34e1dac1',1,'Motorista']]],
  ['setmotoristaname_168',['setMotoristaName',['../class_empresa.html#a5d331058a9294ca09275eb9b7810101d',1,'Empresa']]],
  ['setname_169',['setName',['../class_clientes.html#a3fc0969860c7df6e4f51394681e8cb41',1,'Clientes::setName()'],['../class_motorista.html#a5f74e2ec104aec72748f1be2cc83014f',1,'Motorista::setName()'],['../class_workers.html#a1079f198f1d7a686fa4946e1422c58a4',1,'Workers::setName()']]],
  ['setnif_170',['setNif',['../class_clientes.html#ae17405f970a8c3206e39ca361a72b6dc',1,'Clientes']]],
  ['setun_171',['setUn',['../class_workshop.html#a4beab6268762886e7a5f4b6ac7fc2cf0',1,'Workshop']]],
  ['setyear_172',['setYear',['../class_date.html#a1299c7e1f0080304f082a9225a743957',1,'Date']]],
  ['swap_5fpq_173',['swap_pq',['../class_empresa.html#a290ff5b23de778d4ff57bbe438b5ccde',1,'Empresa']]]
];
