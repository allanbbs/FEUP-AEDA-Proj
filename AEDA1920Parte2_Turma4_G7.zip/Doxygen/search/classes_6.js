var searchData=
[
  ['local_218',['Local',['../class_local.html',1,'']]]
];
